<?php 
	
	define("HOST", "localhost");
	define("USER", "root");
	define("PASS", "");
	define("BASE", "concessionaria2122m");

	$conn = new MySQli(HOST,USER,PASS,BASE);



 ?>